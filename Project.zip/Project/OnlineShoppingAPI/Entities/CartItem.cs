﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OnlineShoppingAPI.Entities
{
    public class CartItem
    {
        [Key]
        
        public string CartItemId { get; set; }
        
        [ForeignKey("Product")]
        
       
        public string ProductId { get; set; }
        
        public int Quantity { get; set; }



        public double TotalPrice { get; set; }
        [ForeignKey("User")]
        public string UserId { get; set; }
        [JsonIgnore]
        public User? User { get; set; }

        [JsonIgnore]
        public Product? Product { get; set; }
        

    }
}
