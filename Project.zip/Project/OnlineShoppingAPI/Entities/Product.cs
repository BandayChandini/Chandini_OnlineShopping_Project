﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OnlineShoppingAPI.Entities
{
    public class Product
    {
        [Key]
        public string ProductId { get; set; }

        [Column(TypeName = "varchar(30)")]
        public string ProductName { get; set; }

        
        public double Price { get; set; }

        // Foreign key for Category
        public string CategoryId { get; set; }

        // Navigation property for Category
        [ForeignKey(nameof(CategoryId))]
        [JsonIgnore]
        public Category? Category { get; set; }

        // Additional properties
        [Column(TypeName = "varchar(20)")]
        public string? Color { get; set; }
        
        public string ImageURL {  get; set; }

        [Column(TypeName = "varchar(30)")]
        public string? Brand { get; set; } 

        // New Brand property

         // New Size property
    }
}
