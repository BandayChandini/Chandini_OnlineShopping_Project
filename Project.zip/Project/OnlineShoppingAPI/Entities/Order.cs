﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace OnlineShoppingAPI.Entities
{
    public class Order
    {
        [Key]
        
        //[DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid OrderId {  get; set; }
        


        public double Totalprice { get; set; }
        [Column(TypeName = "varchar")]
        [StringLength(100)]
        public string OrderStatus {  get; set; }
        [Column(TypeName ="Date")]
        public DateTime DeliveryDate { get; set; }
        [Column(TypeName = "Date")]
        
        public DateTime OrderDate { get; set; }

     
        [ForeignKey("User")]
        //[DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(TypeName = "varchar")]
        [StringLength(10)]

        public string UserId { get; set; }
        [JsonIgnore]
        public User? User { get; set; }
        
    }
}
