﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Repository;

namespace OnlineShoppingAPI.Controllers
{
    // The OrderItemController handles CRUD operations for order items in the online shopping system.
    [Route("api/[controller]")]
    [ApiController]
    public class OrderItemController : ControllerBase
    {
        private readonly IOrderItemRepository _orderitemRepository;
        private IConfiguration _configuration;

        // Constructor for dependency injection of the OrderItem repository
        public OrderItemController(IOrderItemRepository orderitemRepository)
        {
            _orderitemRepository = orderitemRepository; // Inject the order item repository
        }

        // Endpoint to get all order items, accessible by Admin and Customer roles
        [Authorize(Roles = "Admin,Customer")]
        [HttpGet, Route("GetOrderItems")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                // Retrieve all order items from the repository
                var orderitems = await _orderitemRepository.GetAllOrderItems();
                return StatusCode(200, orderitems); // Return the order items with status 200
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to get a specific order item by ID, accessible by Admin and Customer roles
        [Authorize(Roles = "Admin,Customer")]
        [HttpGet, Route("GetOrderItems/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            try
            {
                // Retrieve the order item by ID from the repository
                var orderitems = await _orderitemRepository.GetOrderItemById(id);
                if (orderitems != null)
                {
                    return StatusCode(200, orderitems); // Return the order item with status 200
                }
                else
                {
                    return StatusCode(404, "Invalid Id"); // Return 404 if the order item is not found
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to add a new order item, accessible only by Customers
       [Authorize(Roles = "Customer")]
        [HttpPost, Route("AddOrderItem")]
        public async Task<IActionResult> Add([FromBody] OrderItem orderItem)
        {
            try
            {
                // Check if the incoming model is valid
                if (ModelState.IsValid)
                {
                    orderItem.OrderItemId = "OI" + new Random().Next(1000, 9999);

                    // Add the order item to the repository
                    await _orderitemRepository.AddOrderItem(orderItem);
                    return StatusCode(200, orderItem); // Return the added order item with status 200
                }
                else
                {
                    return BadRequest("Enter Valid Details!"); // Return bad request if the model is invalid
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString()); // Return bad request if an exception occurs
            }
        }
    }
}
