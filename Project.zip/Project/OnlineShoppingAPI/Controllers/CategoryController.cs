﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Repository;

namespace OnlineShoppingAPI.Controllers
{
    // This controller handles CRUD operations for Categories
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryRepository _categoryRepository;
        private IConfiguration _configuration;

        // Constructor for dependency injection
        public CategoryController(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository; // Inject the category repository
        }
        [HttpGet, Route("GetCategoryByName/{name}")]
        [Authorize(Roles = "Customer,Admin")]

        public async Task<IActionResult> GetCategoryByName([FromRoute] string name)
        {
            try
            {
                var category = await _categoryRepository.GetCategoryByName(name);
                if (category != null)
                {
                    return Ok(category);
                }
                else
                {
                    return NotFound("category not found.");
                }
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        // Endpoint to get all categories, accessible to Admin and Customer roles
        [HttpGet, Route("GetAllCategories")]
        [Authorize(Roles = "Admin,Customer")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                // Retrieve all categories from the repository
                var category = await _categoryRepository.GetAllCategories();
                return StatusCode(200, category); // Return the categories with status 200
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message); // Return status 500 if an exception occurs
            }
        }

        // Endpoint to get a specific category by ID, accessible to Admin and Customer roles
        [HttpGet, Route("GetCategory/{id}")]
        [Authorize(Roles = "Admin,Customer")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            try
            {
                // Retrieve the category by ID from the repository
                var category = await _categoryRepository.GetCategoryById(id);
                if (category != null)
                {
                    return StatusCode(200, category); // Return the category with status 200
                }
                else
                {
                    return StatusCode(404, "Invalid Id"); // Return 404 if the category is not found
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message); // Return status 500 if an exception occurs
            }
        }

        // Endpoint to add a new category, accessible only to Admins

        [HttpPost, Route("AddCategory")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Add([FromBody] Category category)
        {
            try
            {
                // Check if the incoming model is valid
                if (ModelState.IsValid)
                {

                    category.CategoryId = "CA" + new Random().Next(1000, 9999);
                    // Add the category to the repository
                    await _categoryRepository.AddCategory(category);
                    return StatusCode(200, category); // Return the added category with status 200
                }
                else
                {
                    return BadRequest("Enter Valid Details!!"); // Return bad request if the model is invalid
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to edit an existing category, accessible only to Admins
        [HttpPut, Route("EditCategory")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit([FromBody] Category category)
        {
            try
            {
                // Update the category in the repository
                await _categoryRepository.UpdateCategory(category);
                return StatusCode(200, category); // Return the updated category with status 200
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to delete a category by ID, accessible only to Admins
        [HttpDelete, Route("DeleteCategory")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            try
            {
                // Delete the category by ID from the repository
                await _categoryRepository.DeleteCategory(id);
                return Ok(); // Return OK status if the deletion is successful
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }
    }
}