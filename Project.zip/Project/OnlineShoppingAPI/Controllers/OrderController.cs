﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Models;
using OnlineShoppingAPI.Repository;

namespace OnlineShoppingAPI.Controllers
{
    // The OrderController handles CRUD operations for orders in the online shopping system.
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
        private IConfiguration _configuration;

        // Constructor for dependency injection of the Order repository
        public OrderController(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository; // Inject the order repository
        }
      
        // Endpoint to get all orders, accessible by Admin and Customer roles

        [Authorize(Roles = "Admin,Customer")]
        [HttpGet, Route("GetOrders")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                // Retrieve all orders from the repository
                var orders = await _orderRepository.GetAllOrders();
                return StatusCode(200, orders); // Return the orders with status 200
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }
        [HttpGet("orders/user/{userId}")]
        [Authorize(Roles = "Admin,Customer")]

        public async Task<IActionResult> GetOrdersByUserId(string userId)
        {
            var orders = await _orderRepository.GetOrdersByUserIdAsync(userId);

            if (orders == null || !orders.Any())
            {
                return NotFound(new { Message = "No orders found for this user." });
            }

            return Ok(orders);
        }

        [HttpGet,Route("AdminDTO")]
        [Authorize(Roles = "Admin,Customer")]

        public async Task<IActionResult> GetAllOrders()
        {
            var orders = await _orderRepository.GetAllOrdersAsync();
            return Ok(orders);
        }



        // Endpoint to get a specific order by ID, accessible by Admin and Customer roles
        [HttpGet, Route("GetOrder/{id}")]
        [Authorize(Roles = "Admin,Customer")]
        public async Task<IActionResult> Get([FromRoute] Guid id)
        {
            try
            {
                // Retrieve the order by ID from the repository
                var order = await _orderRepository.GetOrderById(id);
                if (order != null)
                {
                    return StatusCode(200, order); // Return the order with status 200
                }
                else
                {
                    return StatusCode(404, "Invalid Id"); // Return 404 if the order is not found
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }
      

        // Endpoint to add a new order, accessible only by Customers
        [HttpPost, Route("AddOrder")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Add([FromBody] Order order)
        {
            try
            {
                // Check if the incoming model is valid
                if (ModelState.IsValid)
                {
                    // Generate a new unique ID for the order
                    order.OrderId = Guid.NewGuid();

                    // Add the order to the repository
                    await _orderRepository.Add(order);
                    return StatusCode(200, order); // Return the added order with status 200
                }
                else
                {
                    return BadRequest("Enter Valid Details!"); // Return bad request if the model is invalid
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to delete an order by ID, accessible only by Customers
        [HttpDelete, Route("DeleteOrder")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Delete([FromQuery] Guid id)
        {
            try
            {
                // Delete the order by ID from the repository
                await _orderRepository.Delete(id);
                return Ok(); // Return OK status if the deletion is successful
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }
    }
}
