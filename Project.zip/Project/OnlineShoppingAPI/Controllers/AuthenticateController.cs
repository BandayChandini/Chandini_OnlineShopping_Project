﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Repository;
using OnlineShoppingAPI.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace OnlineShoppingAPI.Controllers
{
    // This controller handles user authentication and authorization tasks
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _configuration;

        // Constructor for dependency injection
        public AuthenticateController(IUserRepository userRepository, IConfiguration configuration)
        {
            _userRepository = userRepository; // Inject user repository
            _configuration = configuration; // Inject configuration for JWT token settings
        }

        // Endpoint to get all users, accessible only to Admins
        [HttpGet, Route("GetAllUsers")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                // Retrieve all users from the repository
                var users = await _userRepository.GetAllUsers();
                return StatusCode(200, users); // Return the users with status 200
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to register a new user, accessible to anyone
        [HttpPost, Route("Registraion")]
        [AllowAnonymous]
        public async Task<IActionResult> Add([FromBody] User user)
        {
            try
            {
                // Check if the incoming model is valid
                if (ModelState.IsValid)
                {
                    // Generate a unique user ID
                    user.UserId = "U" + new Random().Next(1000, 9999);

                    // Register the user in the repository
                    await _userRepository.Register(user);
                    return StatusCode(200, user); // Return the registered user with status 200
                }
                else
                {
                    return BadRequest("Enter valid Details!"); // Return bad request if the model is invalid
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }
        

        // Endpoint to validate a user during login, accessible to anyone
        [HttpPost, Route("ValidUser")]
       [AllowAnonymous]
        public async Task<IActionResult> ValidUser(Login login)
        {
            AuthResponse authReponse = null;

            // Validate the user's credentials
            var user = await _userRepository.ValidUser(login.Email, login.Password);
            if (user != null)
            {
                // Create an authentication response with user details and token
                authReponse = new AuthResponse()
                {
                    UserId = user.UserId,
                    Role = user.Role,
                    UserName = user.Name,
                    Mobile = user.Mobile,
                    Token = GetToken(user), // Generate a JWT token
                };
            }

            return Ok(authReponse); // Return the authentication response
        }
        [HttpGet("{userId}")]
        [AllowAnonymous]

        public async Task<IActionResult> GetUserById(string userId)
        {
            var user = await _userRepository.GetUserById(userId);
            if (user == null)
            {
                return NotFound(new { Message = "User not found" });
            }
            return Ok(user);
        }
        // Update user
        [HttpPut("{userId}")]
        [AllowAnonymous]

        public async Task<IActionResult> UpdateUser(string userId, [FromBody] User user)
        {
            if (userId != user.UserId)
            {
                return BadRequest(new { Message = "UserId mismatch" });
            }
            await _userRepository.UpdateUser(user);
            return Ok(new { Message = "User updated successfully" });
        }
        // Endpoint to edit a user's details, accessible to Admin and Customer roles
        [HttpPut, Route("EditProduct")]
        [Authorize(Roles = "Admin,Customer")]
        public async Task<IActionResult> Edit([FromBody] User user)
        {
            try
            {
                // Update the user in the repository
                await _userRepository.UpdateUser(user);
                return StatusCode(200, user); // Return the updated user with status 200
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to delete a user, accessible to Admin and Customer roles
        [HttpDelete, Route("Deleteuser")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            try
            {
                // Delete the user by ID from the repository
                await _userRepository.DeleteUser(id);
                return Ok(id); // Return the deleted user ID with status 200
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Private method to generate a JWT token for authenticated users
        private string GetToken(User user)
        {
            var issuer = _configuration["Jwt:Issuer"];
            var audience = _configuration["Jwt:Audience"];
            var key = Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]);

            // Define the signing credentials using the secret key
            var signingCredentials = new SigningCredentials(
                new SymmetricSecurityKey(key),
                SecurityAlgorithms.HmacSha512Signature
            );

            // Define the claims for the token payload
            var subject = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, user.Name),
                new Claim(ClaimTypes.Role, user.Role),
            });

            // Set the token expiration time
            var expires = DateTime.UtcNow.AddMinutes(10);

            // Define the security token descriptor
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = subject,
                Expires = expires,
                Issuer = issuer,
                Audience = audience,
                SigningCredentials = signingCredentials
            };

            // Generate the JWT token
            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var jwtToken = tokenHandler.WriteToken(token);

            return jwtToken; // Return the generated token
        }
    }
}
