﻿namespace OnlineShoppingAPI.Models
{
    public class OrderDTO
    {
        public string UserId { get; set; }
        public string OrderItemId { get; set; }

        public Guid OrderId { get; set; }
        public string ProductId { get; set; }

        public string ProductName { get; set; }
        public int Quantity { get; set; }

        public DateTime OrderDate { get; set; }

        public string Address { get; set; }
        public double Totalprice { get; set; }
        public string OrderStatus { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string TransactionMethod { get; set; }
        public string TransactionStatus { get; set; }
        public DateTime TransactionDate { get; set; } = DateTime.Now;







    }
}
