﻿namespace OnlineShoppingAPI.Models
{
    public class Adminorder
    {
        public Guid OrderId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public DateTime OrderDate { get; set; }
        public double Totalprice { get; set; }
        public string Address { get; set; }
        public string OrderStatus { get; set; }
        public string UserId { get; set; }

    }
}
