﻿using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Models;

namespace OnlineShoppingAPI.Repository
{
    public interface ICartItemRepository
    {
        Task<List<CartItem>> GetAllCartItems();
        Task<CartItem> GetCartItemById(string id);
        Task DeleteCartItem(string id);
        Task<bool> DeleteCartByUserId(string userId);

        Task<IEnumerable<CartDTO>> GetCartItemsByUserIdDTO(string userId);
        Task<IEnumerable<CartItem>> GetCartItemsByUserId(string userId);

        Task UpdateCartItem(CartItem cartitem);
        Task AddCartItem(CartItem cartitem);
    }
}
