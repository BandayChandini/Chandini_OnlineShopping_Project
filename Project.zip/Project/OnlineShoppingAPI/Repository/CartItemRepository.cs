﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Models;

namespace OnlineShoppingAPI.Repository
{
    // The CartItemRepository class provides methods to interact with the CartItems in the database.
    public class CartItemRepository : ICartItemRepository
    {
        private readonly OnlineShoppingContext _context;

        // Constructor to initialize the context through dependency injection.
        public CartItemRepository(OnlineShoppingContext context)
        {
            _context = context;
        }
        public async Task<bool> DeleteCartByUserId(string userId)
        {
            // Fetch all cart items for the given user ID
            var cartItems = await _context.CartItems
                                          .Where(c => c.UserId == userId)
                                          .ToListAsync();

            if (cartItems == null || cartItems.Count == 0)
            {
                return false; // No cart items found
            }

            // Remove the cart items from the database
            _context.CartItems.RemoveRange(cartItems);
            await _context.SaveChangesAsync();

            return true; // Cart items deleted successfully
        }

        public async Task<IEnumerable<CartDTO>> GetCartItemsByUserIdDTO(string userId)
        {
            var cartItems = await (from cart in _context.CartItems
                                   join product in _context.Products on cart.ProductId equals product.ProductId
                                   join category in _context.Categories on product.CategoryId equals category.CategoryId
                                   where cart.UserId == userId
                                   select new CartDTO
                                   {
                                       CartItemId = cart.CartItemId,
                                       ProductId = product.ProductId,
                                       CategoryName = category.CategoryName,
                                       ProductName = product.ProductName,
                                       Brand = product.Brand,
                                       Price = product.Price,
                                       Quantity = cart.Quantity,
                                       TotalPrice = cart.Quantity * product.Price
                                   }).ToListAsync();

            return cartItems;
        }


        // Method to add a new CartItem to the database.
        public async Task AddCartItem(CartItem cartitem)
        {
            try
            {
                // Add the CartItem entity to the context and save changes to the database.
                await _context.CartItems.AddAsync(cartitem);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }

        // Method to delete a CartItem from the database by its ID.
        public async Task DeleteCartItem(string id)
        {
            try
            {
                // Find the CartItem entity by its ID.
                var item = await _context.CartItems.FindAsync(id);
                if (item != null)
                {
                    // Remove the found CartItem from the context and save changes to the database.
                    _context.CartItems.Remove(item);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }

        // Method to retrieve all CartItems from the database.
        public async Task<List<CartItem>> GetAllCartItems()
        {
            try
            {
                // Return a list of all CartItem entities in the database.
                return await _context.CartItems.ToListAsync();
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }
        public async Task<IEnumerable<CartItem>> GetCartItemsByUserId(string userId)
        {
            return await _context.CartItems
                .Where(c => c.UserId == userId)
                .Include(c => c.Product) // Include related Product data
                .ToListAsync();
        }

        // Method to retrieve a specific CartItem by its ID.
        public async Task<CartItem> GetCartItemById(string id)
        {
            try
            {
                // Find and return the CartItem entity by its ID.
                var item = await _context.CartItems.FindAsync(id);
                return item;
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }

        // Method to update an existing CartItem in the database.
        public async Task UpdateCartItem(CartItem cartitem)
        {
            try
            {
                // Update the CartItem entity in the context and save changes to the database.
                _context.CartItems.Update(cartitem);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }

       
    }
}
