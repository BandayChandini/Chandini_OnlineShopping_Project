﻿using OnlineShoppingAPI.Entities;
namespace OnlineShoppingAPI.Repository
{
    public interface ICategoryRepository
    {
        Task<List<Category>> GetAllCategories();
        Task<Category> GetCategoryByName(string categoryName);
        Task<Category> GetCategoryById(string id);
        Task DeleteCategory(string id);
        Task UpdateCategory(Category category);
        Task AddCategory(Category category);

    }
}
