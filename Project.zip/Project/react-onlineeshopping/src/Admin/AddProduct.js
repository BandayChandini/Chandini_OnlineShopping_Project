import { useState,useEffect } from "react";
import axios from "axios";
const AddProduct = () => {
    const [products, setProducts] = useState([]);
    const [newProduct, setNewProduct] = useState({
        productId: "",
        productName: "",
        price: 0,
        categoryId: "",
        color: "",
        imageURL: "",
        brand: ""
      });
      useEffect(() => {
        fetchProducts();
      }, []);
      const fetchProducts = async () => {
        try {
          const response = await axios.get("http://localhost:5191/api/Product/GetProducts", {
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("token")}`
                }
            });
          setProducts(response.data);
        } catch (error) {
          console.error("Error fetching products:", error);
          setError("Error fetching products.");
        }
      };
      const [error, setError] = useState("");

      const handleAddProduct = async () => {
        try {
          await axios.post("http://localhost:5191/api/Product/AddProduct", newProduct, {
            headers: {
                Authorization: `Bearer ${sessionStorage.getItem("token")}`
            }
        });
          fetchProducts();
          setNewProduct({
            productId: "",
            productName: "",
            price: 0,
            categoryId: "",
            color: "",
            imageURL: "",
            brand: ""
          });
        } catch (error) {
          console.error("Error adding product:", error);
          setError("Error adding product.");
        }
      };
  return (
    <div className="admin-dashboard d-flex flex-column min-vh-100">
      {/* Main Content */}
      <main className="container mt-4">
        {error && <div className="alert alert-danger">{error}</div>}
      <section className="add-product card mb-4">
          <div className="card-header bg-primary text-white">
            <h3>Add New Product</h3>
          </div>
          <div className="card-body">
            <form>
            <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Product ID"
                  value={newProduct.productId}
                  onChange={(e) => setNewProduct({ ...newProduct, productId: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Product Name"
                  value={newProduct.productName}
                  onChange={(e) => setNewProduct({ ...newProduct, productName: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Brand"
                  value={newProduct.brand}
                  onChange={(e) => setNewProduct({ ...newProduct, brand: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="number"
                  className="form-control"
                  placeholder="Price"
                  value={newProduct.price}
                  onChange={(e) => setNewProduct({ ...newProduct, price: parseFloat(e.target.value) })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Category ID"
                  value={newProduct.categoryId}
                  onChange={(e) => setNewProduct({ ...newProduct, categoryId: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Color"
                  value={newProduct.color}
                  onChange={(e) => setNewProduct({ ...newProduct, color: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Image URL"
                  value={newProduct.imageURL}
                  onChange={(e) => setNewProduct({ ...newProduct, imageURL: e.target.value })}
                />
              </div>
              <button
                type="button"
                className="btn btn-animate"
                onClick={handleAddProduct}
              >
                Add Product
              </button>
            </form>
          </div>
        </section>
        </main>
    </div>
  );
};
export default AddProduct;
