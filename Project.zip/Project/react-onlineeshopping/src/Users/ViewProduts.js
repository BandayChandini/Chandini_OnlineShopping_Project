import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import img1 from '../../src/Assets/products.jpg';

const ViewProducts = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [filters, setFilters] = useState({
    productName: "",
    minPrice: "",
    maxPrice: "",
    color: "",
    brand: "",
    categoryName: ""
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [filters, searchQuery]);

  const fetchProducts = async () => {
    try {
      const response = await axios.get("http://localhost:5191/api/Product/GetAllProductsDTO", {
        headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`
        }
    });
      setProducts(response.data);
      setFilteredProducts(response.data);
    } catch (error) {
      console.error("Error fetching products:", error);
      setError("Error fetching products.");
    }
  };

  const handleFilterChange = (e) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value
    });
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const applyFilters = () => {
    const filteredData = products.filter((product) => {
      const productName = product.productName ? product.productName.toLowerCase() : '';
      const color = product.color ? product.color.toLowerCase() : '';
      const brand = product.brand ? product.brand.toLowerCase() : '';
      const categoryName = product.categoryName ? product.categoryName.toLowerCase() : '';

      return (
        (!filters.productName || productName.includes(filters.productName.toLowerCase())) &&
        (!filters.minPrice || product.price >= filters.minPrice) &&
        (!filters.maxPrice || product.price <= filters.maxPrice) &&
        (!filters.color || color.includes(filters.color.toLowerCase())) &&
        (!filters.brand || brand.includes(filters.brand.toLowerCase())) &&
        (!filters.categoryName || categoryName.includes(filters.categoryName.toLowerCase()))
      );
    });
    setFilteredProducts(filteredData);
  };

  const handleAddToCart = async (productId) => {
    try {
      const userId = sessionStorage.getItem('userId');
      if (!userId) {
        setError("User not logged in.");
        return;
      }
  
      const product = products.find(p => p.productId === productId);
      const cartItem = {
        cartItemId:'',
        productId: productId,
        userId: userId,
        price: product.price,
        quantity: 1,
        totalPrice: product.price
      };
  
      const response = await axios.post("http://localhost:5191/api/CartItem/AddCartItem", cartItem, {
        headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`
        }
    });
  
      if (response.status === 201) {
        console.log(`Product ${productId} added to cart successfully`);
      } else {
        setError("Product  added to the cart successfully...");
      }
    } catch (error) {
      console.error("Error adding product to cart:", error);
      setError("An error occurred while adding the product to the cart.");
    }
  };

  const handleApplyFilters = (e) => {
    e.preventDefault();
    applyFilters();
  };

  const finalFilteredProducts = filteredProducts.filter(product =>
    product.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.color.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.brand.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="user-dashboard d-flex flex-column min-vh-100">
      {/* Main Content */}
      <div className="d-flex">
        {/* Sidebar */}
        <aside className="sidebar bg-light p-4">
          <h4>Filter Products</h4>
          <form onSubmit={handleApplyFilters}>
            <div className="form-group mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Product Name"
                name="productName"
                value={filters.productName}
                onChange={handleFilterChange}
              />
            </div>
            <div className="form-group mb-3">
              <input
                type="number"
                className="form-control"
                placeholder="Min Price"
                name="minPrice"
                value={filters.minPrice}
                onChange={handleFilterChange}
              />
            </div>
            <div className="form-group mb-3">
              <input
                type="number"
                className="form-control"
                placeholder="Max Price"
                name="maxPrice"
                value={filters.maxPrice}
                onChange={handleFilterChange}
              />
            </div>
            <div className="form-group mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Color"
                name="color"
                value={filters.color}
                onChange={handleFilterChange}
              />
            </div>
            <div className="form-group mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Brand"
                name="brand"
                value={filters.brand}
                onChange={handleFilterChange}
              />
            </div>
            <div className="form-group mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Category Name"
                name="categoryName"
                value={filters.categoryName}
                onChange={handleFilterChange}
              />
            </div>
          </form>
        </aside>

        {/* Product List */}
        <main className="container mt-4">
          {error && <div className="alert alert-danger">{error}</div>}

          {/* Search Bar */}
          <div className="mb-4">
            <input
              type="text"
              className="form-control"
              placeholder="Search Products by Name, Color, Brand..."
              value={searchQuery}
              onChange={handleSearchChange}
            />
          </div>

          {/* Product Cards */}
          <section className="product-cards">
            <div className="row">
              {finalFilteredProducts.length > 0 ? (
                finalFilteredProducts.map((product) => (
                  <div className="col-md-4 mb-4" key={product.productId}>
                    <div className="card">
                      <img
                        src={img1}
                        className="card-img-top"
                        alt={product.productName}
                        style={{ height: "200px", objectFit: "cover" }}
                      />
                      <div className="card-body">
                        <h5 className="card-title">{product.productName}</h5>
                        <p className="card-text">Brand: {product.brand}</p>
                        <p className="card-text">Price: ${product.price}</p>
                        <p className="card-text">Color: {product.color}</p>
                        <p className="card-text">Category: {product.categoryName}</p>
                        <button
                          className="btn btn-animate"
                          onClick={() => handleAddToCart(product.productId)}
                        >
                          Add to Cart
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-12 text-center">
                  <p>No products found.</p>
                </div>
              )}
            </div>
          </section>
        </main>
      </div>
    </div>
  );
};

export default ViewProducts;
