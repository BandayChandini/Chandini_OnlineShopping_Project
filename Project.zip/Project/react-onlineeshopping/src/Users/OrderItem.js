import React, { useState } from 'react';
import axios from 'axios';

const AddOrderItem = () => {
    const [orderItem, setOrderItem] = useState({
        orderId: '',
        productId: '',
        price: '',
        totalPrice: '',
        quantity: ''
    });
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const handleChange = (e) => {
        setOrderItem({
            ...orderItem,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:5191/api/OrderItem/AddOrderItem', {
                OrderId: orderItem.orderId,
                ProductId: orderItem.productId,
                Price: parseFloat(orderItem.price),
                TotalPrice: parseFloat(orderItem.totalPrice),
                Quantity: parseInt(orderItem.quantity)
            }, {
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("token")}`
                }
            });
            setSuccess('Order item added successfully!');
            setError('');
            // Optionally clear the form or redirect
            setOrderItem({
                orderId: '',
                productId: '',
                price: '',
                totalPrice: '',
                quantity: ''
            });
        } catch (error) {
            console.error("Error adding order item:", error);
            setError("Error adding order item.");
            setSuccess('');
        }
    };

    return (
        <div className="container mt-4">
            <h2>Add Order Item</h2>
            {error && <div className="alert alert-danger">{error}</div>}
            {success && <div className="alert alert-success">{success}</div>}
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="orderId">Order ID</label>
                    <input
                        type="text"
                        className="form-control"
                        id="orderId"
                        name="orderId"
                        value={orderItem.orderId}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="productId">Product ID</label>
                    <input
                        type="text"
                        className="form-control"
                        id="productId"
                        name="productId"
                        value={orderItem.productId}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="price">Price</label>
                    <input
                        type="number"
                        step="0.01"
                        className="form-control"
                        id="price"
                        name="price"
                        value={orderItem.price}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="totalPrice">Total Price</label>
                    <input
                        type="number"
                        step="0.01"
                        className="form-control"
                        id="totalPrice"
                        name="totalPrice"
                        value={orderItem.totalPrice}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="quantity">Quantity</label>
                    <input
                        type="number"
                        className="form-control"
                        id="quantity"
                        name="quantity"
                        value={orderItem.quantity}
                        onChange={handleChange}
                        required
                    />
                </div>
                <button type="submit" className="btn btn-primary">Add Order Item</button>
            </form>
        </div>
    );
};

export default AddOrderItem;
