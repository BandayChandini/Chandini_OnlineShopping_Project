
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './OrdersList.css'; // Import the CSS file
const OrdersList = () => {
    const [orders, setOrders] = useState([]);
    const [error, setError] = useState("");
    const userId = sessionStorage.getItem("userId");

    useEffect(() => {
        if (userId) {
            fetchOrders();
        } else {
            setError("User ID not found. Please log in.");
        }
    }, [userId]);

    const fetchOrders = async () => {
        try {
            const response = await axios.get(`http://localhost:5191/api/Order/orders/user/${userId}`, {
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("token")}`
                }
            });
            setOrders(response.data);
        } catch (error) {
            console.error("Error fetching orders:", error);
            setError("Error fetching orders.");
        }
    };

    const groupOrdersByOrderId = () => {
        return orders.reduce((acc, order) => {
            acc[order.orderId] = acc[order.orderId] || [];
            acc[order.orderId].push(order);
            return acc;
        }, {});
    };

    const groupedOrders = groupOrdersByOrderId();

    return (
        <div className="container">
            {error && <div className="alert alert-danger">{error}</div>}
            <h2>Your Orders</h2>
            {Object.keys(groupedOrders).length > 0 ? (
                <table className="table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Order Item ID</th>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Order Date</th>
                            <th>Address</th>
                            <th>Total Price</th>
                            <th>Delivery Date</th>
                            <th>Payment Method</th>
                        </tr>
                    </thead>
                    <tbody>
                        {Object.entries(groupedOrders).map(([orderId, orderItems]) =>
                            orderItems.map((order, index) => (
                                <tr key={order.orderItemId}>
                                    <td>{index === 0 ? orderId : ""}</td>
                                    <td>{order.orderItemId}</td>
                                    <td>{order.productName}</td>
                                    <td>{order.quantity}</td>
                                    <td>{new Date(order.orderDate).toLocaleDateString()}</td>
                                    <td>{order.address}</td>
                                    <td>Rs{order.totalprice.toFixed(2)}</td>
                                    
                                    <td>{order.deliveryDate ? new Date(order.deliveryDate).toLocaleDateString() : 'N/A'}</td>
                                    <td>{order.transactionMethod}</td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            ) : (
                <div className="alert alert-warning">No orders found</div>
            )}
        </div>
    );
};

export default OrdersList;

