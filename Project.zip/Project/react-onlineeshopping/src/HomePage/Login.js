import React from "react";
import { useNavigate } from "react-router-dom";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Login.css"; // Custom CSS for animations and styles

const LoginSchema = Yup.object().shape({
  email: Yup.string().email("Invalid email").required("Email is required"),
  password: Yup.string().required("Password is required"),
});

const Login = () => {
  const navigate = useNavigate();

  const handleLogin = async (values, { setSubmitting, setErrors }) => {
    try {
      const response = await axios.post(
        "http://localhost:5191/api/Authenticate/ValidUser",
        values, {
          headers: {
              Authorization: `Bearer ${sessionStorage.getItem("token")}`
          }
      }
      );

      const user = response.data;
      if (!user.token) {
        setErrors({ apiError: "Invalid credentials. Please try again." });
      } else {
        sessionStorage.setItem("token", user.token);
        sessionStorage.setItem("userId", user.userId);

        user.role === "Admin"
          ? navigate("/admin-dashboard")
          : navigate("/user-dashboard");
      }
    } catch (error) {
      setErrors({ apiError: "An error occurred. Please try again later." });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="login-page d-flex flex-column min-vh-100">
      <div className="container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="card form-animate">
              <div className="card-header text-center bg-secondary text-white">
                <h3>Login</h3>
              </div>
              <div className="card-body p-4">
                <Formik
                  initialValues={{ email: "", password: "" }}
                  validationSchema={LoginSchema}
                  onSubmit={handleLogin}
                >
                  {({ isSubmitting, errors }) => (
                    <Form>
                      <div className="form-group mb-3">
                        <label htmlFor="email">Email</label>
                        <Field
                          type="email"
                          name="email"
                          className="form-control input-animate"
                          placeholder="Enter your email"
                        />
                        <ErrorMessage
                          name="email"
                          component="div"
                          className="text-danger"
                        />
                      </div>

                      <div className="form-group mb-3">
                        <label htmlFor="password">Password</label>
                        <Field
                          type="password"
                          name="password"
                          className="form-control input-animate"
                          placeholder="Enter your password"
                        />
                        <ErrorMessage
                          name="password"
                          component="div"
                          className="text-danger"
                        />
                      </div>

                      {errors.apiError && (
                        <div className="alert alert-danger text-center">
                          {errors.apiError}
                        </div>
                      )}

                      <div className="d-flex justify-content-between">
                        <button
                          type="submit"
                          className="btn btn-primary btn-animate"
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? "Logging in..." : "Login"}
                        </button>
                        <button
                          type="button"
                          className="btn btn-secondary btn-animate"
                          onClick={() => navigate("/register")}
                        >
                          Register
                        </button>
                      </div>
                    </Form>
                  )}
                </Formik>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
