import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

const Register = () => {
  const [user, setUser] = useState({
    userId: '',
    name: '',
    email: '',
    password: '',
    role: '',
    address:'',
    mobile: '',
  });
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const validateForm = () => {
    const { name, email, password, role, address, mobile } = user;
    if (!name || !email || !password || !role || !address || !mobile) {
      setMessage("Please enter all fields");
      return false;
    }
    if (role !== 'Customer' && role !== 'Admin') {
      setMessage("Role must be either 'Customer' or 'Admin'");
      return false;
    }
    return true;
  };

  const save = (e) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }

    console.log(user);
    axios
      .post("http://localhost:5191/api/Authenticate/Registraion", user, {
        headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`
        }
    })
      .then((res) => {
        console.log(res.data);
        setMessage("Successfully registered");
        setTimeout(() => {
          navigate("/");
        }, 2000);
      })
      .catch((err) => {
        console.log(err);
        setMessage("Registration failed");
      });
  };

  const navigateToLogin = () => {
    navigate("/");
  };

  return (
    <div className="register-bg d-flex flex-column min-vh-100">
      

      {/* Main Content */}
      <div className="container mt-5 flex-grow-1">
        <div className="row justify-content-center">
          <div className="col-md-8">
            <div className="card shadow-lg form-animate">
              <div className="card-header text-center bg-secondary text-white">
                <h3>Register</h3>
              </div>
              <div className="card-body p-4">
                <form onSubmit={save}>
                  <div className="mb-3 field-animate">
                    <label htmlFor="name" className="form-label">Name</label>
                    <input
                      type="text"
                      className="form-control input-animate"
                      id="name"
                      value={user.name}
                      onChange={(e) => setUser((prevObj) => ({
                        ...prevObj, name: e.target.value,
                      }))}
                    />
                  </div>
                  <div className="mb-3 field-animate">
                    <label htmlFor="email" className="form-label">Email</label>
                    <input
                      type="email"
                      className="form-control input-animate"
                      id="email"
                      value={user.email}
                      onChange={(e) => setUser((prevObj) => ({
                        ...prevObj, email: e.target.value,
                      }))}
                    />
                  </div>
                  <div className="mb-3 field-animate">
                    <label htmlFor="password" className="form-label">Password</label>
                    <input
                      type="password"
                      className="form-control input-animate"
                      id="password"
                      value={user.password}
                      onChange={(e) => setUser((prevObj) => ({
                        ...prevObj, password: e.target.value,
                      }))}
                    />
                  </div>
                  <div className="mb-3 field-animate">
                    <label htmlFor="role" className="form-label">Role</label>
                    <input
                      type="text"
                      className="form-control input-animate"
                      id="role"
                      value={user.role}
                      onChange={(e) => setUser((prevObj) => ({
                        ...prevObj, role: e.target.value,
                      }))}
                    />
                  </div>
                  <div className="mb-3 field-animate">
                    <label htmlFor="name" className="form-label">Address</label>
                    <input
                      type="text"
                      className="form-control input-animate"
                      id="address"
                      value={user.address}
                      onChange={(e) => setUser((prevObj) => ({
                        ...prevObj, address: e.target.value,
                      }))} kadapa
                    />
                  </div>
                  <div className="mb-3 field-animate">
                    <label htmlFor="mobile" className="form-label">Mobile No.</label>
                    <input
                      type="text"
                      className="form-control input-animate"
                      id="mobile"
                      value={user.mobile}
                      onChange={(e) => setUser((prevObj) => ({
                        ...prevObj, mobile: e.target.value,
                      }))}
                    />
                  </div>
                  <button type="submit" className="btn btn-primary btn-animate">
                    Register
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary ms-2 btn-animate"
                    onClick={navigateToLogin}
                  >
                    Back to Home
                  </button>
                  {message && <p className="text-danger mt-3">{message}</p>}
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

    
    </div>
  );
};

export default Register;