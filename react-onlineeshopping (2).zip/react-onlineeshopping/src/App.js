import './App.css';
import { BrowserRouter,Route,  Routes} from "react-router-dom";
import Layout from './HomePage/Layout';
import Login from './HomePage/Login';
import Register from './HomePage/Register';
import Admin from './Admin/Admin';
import GetProducts from './Admin/GetProducts';
import AddProduct from './Admin/AddProduct';
import ViewCart from './Users/viewcart';
import User from './Users/User';
import ViewProducts from './Users/ViewProduts';
import Transaction from './Users/Treansactions';
import GetAllUsers from './Admin/GetAllUsers';
import Categories from './Admin/Categories';
import OrdersList from './Users/UserOrder';
import GetAllOrders from './Admin/OrdersList';
import Profile from './Admin/UpdateProduct';
import UserProfile from './Users/UserProfile';
import HomePage from './HomePage/HomePage';
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          {/* Anonymous User */}
          <Route path="/" element={<Layout />}>
            <Route path="login" element={<Login />} />
            <Route path="register" element={<Register />} />
            <Route path="/home" element={<HomePage />} />

          </Route>
          {/* Admin Dashboard */}
          <Route path="admin-dashboard" element={<Admin />}>
            <Route path="getall" element={<GetProducts />} />
            <Route path="add" element={<AddProduct />} />
            <Route path="allusers" element={<GetAllUsers />} />
            <Route path="allorders" element={<GetAllOrders />} />
            <Route path="profile" element={<Profile />} />

            <Route path="category" element={<Categories />} />
          </Route>
            {/* User Dashboard */}
            <Route path="user-dashboard" element={<User />}>
            <Route path="viewcart" element={<ViewCart />}/>
            <Route path="GetAll" element={<ViewProducts/>}/>
            <Route path="transaction" element={<Transaction/>}/>
            <Route path="orders" element={<OrdersList/>}/>
            <Route path="userprofile" element={<UserProfile/>}/>

            </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}
export default App;
