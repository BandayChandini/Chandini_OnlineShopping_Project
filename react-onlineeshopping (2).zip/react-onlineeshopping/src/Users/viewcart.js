import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import img3 from '../Assets/products.jpg';
import axios from "axios";

const ViewCart = () => {
  const [cartItems, setCartItems] = useState([]);
  const [error, setError] = useState("");
  const [totalPrice, setTotalPrice] = useState(0);
  const userId = sessionStorage.getItem("userId"); // Fetch user ID from session storage
  const navigate = useNavigate();

  useEffect(() => {
    if (userId) {
      fetchCartItems(); // Fetch items if userId is available
    } else {
      setError("User ID not found. Please log in.");
    }
  }, [userId]);

  const fetchCartItems = async () => {
    try {
      const response = await axios.get(`http://localhost:5191/api/CartItem/GetCartItemsByUserIdDTO/${userId}`, {
        headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`
        }
    });
      console.log("Fetched cart items:", response.data); // Debugging line
      setCartItems(response.data); // Update state with fetched items
      calculateTotalPrice(response.data);
    } catch (error) {
      console.error("Error fetching cart items:", error);
      setError("Error fetching cart items."); // Set error state if fetch fails
    }
  };

  let calculateTotalPrice = (items) => {
    const total = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
    setTotalPrice(total);
  };

  const handleRemoveItem = async (cartItemId) => {
    if (!cartItemId) {
      alert("Cart item ID is invalid");
      return;
    }

    try {
      const res = await axios.delete(`http://localhost:5191/api/CartItem/DeleteCartItem?id=${cartItemId}`, {
        headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`
        }
    });
      console.log("Item removed:", res.data);

      // Update cart items after successful deletion
      const updatedCartItems = cartItems.filter((item) => item.cartItemId !== cartItemId);
      setCartItems(updatedCartItems);

      // Recalculate total price
      const updatedTotalPrice = updatedCartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
      setTotalPrice(updatedTotalPrice);
      
    } catch (error) {
      console.error("Error removing item from cart:", error);
      alert("Failed to remove item from cart."); // Alert user if deletion fails
    }
  };

  const handleQuantityChange = (cartItemId, newQuantity) => {
    // Ensure quantity is a positive number
    const quantity = Math.max(1, newQuantity);
    const updatedCartItems = cartItems.map(item =>
      item.cartItemId === cartItemId ? { ...item, quantity, totalPrice: item.price * quantity } : item
    );
    setCartItems(updatedCartItems);
    calculateTotalPrice(updatedCartItems);
  };

  const AddOrder = () => {
    const orderDate = new Date();
    const deliveryDate = new Date(orderDate);
    deliveryDate.setDate(orderDate.getDate() + 7); // Add 7 days

    // Format dates as ISO strings
    const orderDateString = orderDate.toISOString();
    const deliveryDateString = deliveryDate.toISOString();
    const productId = cartItems.length > 0 ? cartItems[0].productId : "unknown";

    const order = {
      address: "Srikakulam",
      totalprice: totalPrice, // total price from props
      orderStatus: "Processing",
      orderDate: orderDateString,
      deliveryDate: deliveryDateString,
      ProductId: productId, 
      userId: sessionStorage.getItem("userId")
    };

    axios
      .post("http://localhost:5191/api/Order/AddOrder", order, {
        headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`
        }
    })
      .then((response) => {
        sessionStorage.setItem("orderId", response.data.orderId);
        sessionStorage.setItem("totalPrice", totalPrice);
        console.log("order created", response.data);
        const orderId = response.data.orderId;

        // Loop through cart items and create order items
        for (let item of cartItems) {
          AddOrderItem(item, orderId);
        }

        // Clear cart after successful order creation
        clearCart();
        
        // Navigate to transaction or another page after successful order
        navigate("/user-dashboard/transaction");
      })
      .catch((error) => console.log(error));
  };

  const AddOrderItem = (item, orderId) => {
    const orderItem = {
      orderItemId: "0",  // Assuming this will be auto-generated
      orderId: orderId,
      productId: item.productId,
      price: item.price,
      quantity: item.quantity,
      totalPrice: item.price * item.quantity,
    };
    console.log("Adding OrderItem:", orderItem);

    axios
      .post("http://localhost:5191/api/OrderItem/AddOrderItem", orderItem, {
        headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`
        }
    })
      .then((response) => {
        console.log("Order item added:", response.data);
      })
      .catch((error) => console.log(error));
  };

  const clearCart = async () => {
    try {
      await axios.delete(`http://localhost:5191/api/CartItem/DeleteCartByUserId/${userId}`, {
        headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`
        }
    });
      setCartItems([]);  // Clear cart items in UI
      setTotalPrice(0);  // Reset total price
    } catch (error) {
      console.error("Error clearing the cart:", error);
      alert("Failed to clear the cart."); // Alert user if clearing fails
    }
  };

  return (
    <div className="cart-item d-flex flex-column min-vh-100">
      <div className="container mt-4">
        {error && <div className="alert alert-danger">{error}</div>}

        <section className="cart-list">
          <div className="card">
            <div className="card-header bg-success text-white">
              <h3>Cart Items</h3>
            </div>
            <div className="card-body">
              <div className="row">
                {cartItems.length > 0 ? (
                  cartItems.map((item) => (
                    <div className="col-md-4 mb-4" key={item.cartItemId}>
                      <div className="card">
                        <img
                          src={img3} // Placeholder image URL
                          className="card-img-top"
                          alt={item.productName}
                          style={{ height: "200px", objectFit: "cover" }}
                        />
                        <div className="card-body">
                          <h5 className="card-title">{item.productName}</h5>
                          <p className="card-text">Brand: {item.brand}</p>
                          <p className="card-text">Price: ${item.price}</p>
                          <p className="card-text">Category: {item.categoryName}</p>
                          <div className="form-group mb-3">
                            <input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={(e) => handleQuantityChange(item.cartItemId, parseInt(e.target.value))}
                              className="form-control"
                            />
                          </div>
                          <p className="card-text">Total Price: ${item.totalPrice.toFixed(2)}</p>
                          <button
                            className="btn btn-danger"
                            onClick={() => handleRemoveItem(item.cartItemId)}
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="col-12 text-center">
                    <p>No items in cart.</p>
                  </div>
                )}
              </div>
              <div className="total-price mt-4">
                <h3>Total Price: Rs{totalPrice.toFixed(2)}</h3>
              </div>
              <button className="btn btn-animate mt-3" onClick={AddOrder}>Make Order</button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default ViewCart;
