import React, { useEffect } from "react";
import { Link, Outlet } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import './User.css'; // Import your CSS file

const User = () => {
  const navigate = useNavigate();
  useEffect(() => {
    if (sessionStorage.getItem("token") === null) {
      navigate("/login");
    }
  }, [navigate]);

  return (
    <div className="user-dashboard d-flex flex-column min-vh-100">
      <header className="header py-3 shadow-sm">
        <div className="container">
          <div className="d-flex justify-content-between align-items-center">
            <h1 className="header-title">User Dashboard</h1>
            <h2 className="header-subtitle">Logged in as: {sessionStorage.getItem("userId")}</h2>
            <nav>
              <ul className="navbar-nav d-flex flex-row">
                <li className="nav-item mx-2">
                  <Link className="nav-link" to="/home">
                    Home
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link" to="getall">
                    View Products
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link" to="viewcart">
                    View Cart
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link" to="transaction">
                    Transaction
                  </Link>
                </li>
                
                <li className="nav-item mx-2">
                  <Link className="nav-link" to="orders">
                    Orders
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link" to="userprofile">
                    UpdateProfile
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link" to="/login">
                    Log Out
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow-1">
        <Outlet />
      </main>

      <footer className="footer bg-dark text-white text-center py-4 mt-auto">
        <div className="container">
          <p className="mb-0">&copy; 2024 ShopEase. All rights reserved.</p>
          <nav className="mt-2">
            <Link to="/about" className="text-white text-decoration-none mx-3">
              About Us
            </Link>
            <Link to="/contact" className="text-white text-decoration-none mx-3">
              Contact
            </Link>
            <Link to="/help" className="text-white text-decoration-none mx-3">
              Help
            </Link>
            <Link to="/mailus" className="text-white text-decoration-none mx-3">
              Mail Us
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  );
};

export default User;
