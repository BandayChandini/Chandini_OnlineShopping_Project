import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const UserProfile = () => {
    const [user, setUser] = useState({
        userId: "",
        name: "",
        email: "",
        password: "",
        role: "",
        address: "",
        mobile: ""
    });
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    // Fetch the user ID from session storage and make API call to fetch user details
    useEffect(() => {
        const userId = sessionStorage.getItem("userId");
        if (userId) {
            axios
                .get(`http://localhost:5191/api/Authenticate/${userId}`, {
                    headers: {
                        Authorization: `Bearer ${sessionStorage.getItem("token")}`
                    }
                })
                .then((res) => {
                    if (res.status === 200) {
                        setUser(res.data);
                    } else {
                        setError("Error fetching profile data");
                    }
                })
                .catch(() => {
                    setError("Error fetching profile data");
                });
        }
    }, []);

    // Handle changes in form input fields
    const handleChange = (e) => {
        const { name, value } = e.target;
        setUser({ ...user, [name]: value });
    };

    // Submit the form to update user profile
    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true); // Start loading
        axios
            .put(`http://localhost:5191/api/Authenticate/${user.userId}`, user, {
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("token")}`
                }
            })
            .then((res) => {
                if (res.status === 200) {
                    setSuccess("Profile updated successfully");
                    setError("");
                } else {
                    setError("Error updating profile");
                }
            })
            .catch(() => {
                setError("Error updating profile");
            })
            .finally(() => {
                setLoading(false); // Stop loading
            });
    };

    return (
        <div className="profile-container">
            <h2 className="profile-title">Edit Your Profile</h2>
            <form onSubmit={handleSubmit} className="profile-form">
                <div className="form-group">
                    <label htmlFor="userId">User ID:</label>
                    <input
                        type="text"
                        id="userId"
                        name="userId"
                        value={user.userId}
                        className="form-control readonly"
                        readOnly
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="name">Name:</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value={user.name}
                        onChange={handleChange}
                        className="form-control"
                        required
                        placeholder="Enter your name"
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="email">Email:</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={user.email}
                        onChange={handleChange}
                        className="form-control"
                        required
                        placeholder="Enter your email"
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password:</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={user.password}
                        onChange={handleChange}
                        className="form-control"
                        required
                        placeholder="Enter a secure password"
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="role">Role:</label>
                    <input
                        type="text"
                        id="role"
                        name="role"
                        value={user.role}
                        className="form-control readonly"
                        readOnly
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="address">Address:</label>
                    <input
                        type="text"
                        id="address"
                        name="address"
                        value={user.address}
                        onChange={handleChange}
                        className="form-control"
                        required
                        placeholder="Enter your address"
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="mobile">Mobile Number:</label>
                    <input
                        type="text"
                        id="mobile"
                        name="mobile"
                        value={user.mobile}
                        onChange={handleChange}
                        className="form-control"
                        required
                        placeholder="Enter your mobile number"
                    />
                </div>
                <button type="submit" className="btn btn-animate">
                    {loading ? (
                        <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    ) : (
                        "Save Changes"
                    )}
                </button>
                {success && <p className="success-message">{success}</p>}
                {error && <p className="error-message">{error}</p>}
            </form>
        </div>
    );
};

export default UserProfile;
