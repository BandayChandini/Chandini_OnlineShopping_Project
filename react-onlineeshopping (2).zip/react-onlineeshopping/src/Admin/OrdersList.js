import React, { useState, useEffect } from 'react';
import axios from 'axios';

const GetAllOrders = () => {
    const [orders, setOrders] = useState([]);
    const [filteredOrders, setFilteredOrders] = useState([]);
    const [error, setError] = useState("");

    useEffect(() => {
        fetchOrders();
    }, []);

    const fetchOrders = async () => {
        try {
            const response = await axios.get('http://localhost:5191/api/Order/AdminDTO', {
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("token")}`
                }
            });
            setOrders(response.data);
            setFilteredOrders(response.data); // Initialize filtered orders
        } catch (error) {
            setError("Error fetching orders.");
        }
    };

    // const handleUpdateOrderStatus = (orderID, newStatus) => {
    //     axios
    //         .put(`http://localhost:5191/api/Order/${orderID}/UpdateOrderstatus`, newStatus, {
    //             headers: {
    //                 Authorization: `Bearer ${sessionStorage.getItem("token")}`,
    //                 'Content-Type': 'application/json'
    //             }
    //         })
    //         .then(() => {
    //             setOrders((prevOrders) =>
    //                 prevOrders.map((order) =>
    //                     order.orderId === orderID ? { ...order, orderStatus: newStatus } : order
    //                 )
    //             );
    //             alert("Order status updated successfully!");
    //         })
    //         .catch((error) => {
    //             console.error("Error updating order status:", error.response ? error.response.data : error.message);
    //         });
    // };

    // const handleSearch = (e) => {
    //     const searchValue = e.target.value;
    //     setSearchUserId(searchValue);

    //     // Filter orders by userId
    //     if (searchValue) {
    //         const filtered = orders.filter(order =>
    //             order.userId.toLowerCase().includes(searchValue.toLowerCase())
    //         );
    //         setFilteredOrders(filtered);
    //     } else {
    //         setFilteredOrders(orders); // Reset to all orders if search is cleared
    //     }
    // };

    return (
        <div className="container mt-4">
            <h2>All Orders</h2>
           
            {error && <div className="alert alert-danger">{error}</div>}
            {filteredOrders.length > 0 ? (
                <table className="table table-bordered">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Order Date</th>
                            <th>Total Price</th>
                             <th>Address</th>
                            {/*<th>Order Status</th> */}
                            <th>User ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredOrders.map((order) => (
                            <tr key={order.orderId}>
                                <td>{order.orderId}</td>
                                <td>{order.productName}</td>
                                <td>{order.quantity}</td>
                                <td>{new Date(order.orderDate).toLocaleDateString()}</td>
                                <td>Rs{order.totalprice}</td>
                                <td>{order.address}</td>
                                {/* <td>{order.orderStatus}</td> */}
                                <td>{order.userId}</td>
                                {/* <td>
                                    <button
                                        onClick={() => handleUpdateOrderStatus(order.orderId, 'Delivered')}
                                        className="btn btn-success"
                                    >
                                        Mark as Completed
                                    </button>
                                    <button
                                        onClick={() => handleUpdateOrderStatus(order.orderId, 'Cancelled')}
                                        className="btn btn-danger ms-2"
                                    >
                                        Mark as Cancelled
                                    </button>
                                </td> */}
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <div>No orders found.</div>
            )}
        </div>
    );
};

export default GetAllOrders;
