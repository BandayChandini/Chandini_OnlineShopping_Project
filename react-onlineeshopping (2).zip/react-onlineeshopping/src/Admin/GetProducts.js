import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import imageURL from '../Assets/products.jpg';
import './GetProducts.css'; // Import the custom CSS file for additional styling

const GetProducts = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingProduct, setEditingProduct] = useState(null);
  const [editProduct, setEditProduct] = useState({});
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get("http://localhost:5191/api/Product/GetProducts", {
        headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`
        }
    });
      setProducts(response.data);
      setFilteredProducts(response.data);
    } catch (error) {
      console.error("Error fetching products:", error);
      setError("Error fetching products.");
    }
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    const lowercasedTerm = e.target.value.toLowerCase();
    const filtered = products.filter(product =>
      product.productName.toLowerCase().includes(lowercasedTerm) ||
      product.brand.toLowerCase().includes(lowercasedTerm) ||
      product.color.toLowerCase().includes(lowercasedTerm)
    );
    setFilteredProducts(filtered);
  };

  const handleEditProduct = async () => {
    try {
      await axios.put("http://localhost:5191/api/Product/EditProduct", editProduct, {
        headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`
        }
    });
      fetchProducts();
      setEditingProduct(null);
      setEditProduct({});
    } catch (error) {
      console.error("Error updating product:", error);
      setError("Error updating product.");
    }
  };

  const handleDeleteProduct = async (productId) => {
    try {
      await axios.delete(`http://localhost:5191/api/Product/DeleteProduct/${productId}`, {
        headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`
        }
    });
      fetchProducts();
    } catch (error) {
      console.error("Error deleting product:", error);
      setError("Error deleting product.");
    }
  };

  const handleEditClick = (product) => {
    setEditingProduct(product.productId);
    setEditProduct({ ...product });
  };

  const handleGoHome = () => {
    navigate('/'); // Redirect to the Home Page
  };

  return (
    <div className="container mt-4">
      {error && <div className="alert alert-danger">{error}</div>}

      <section className="search-bar mb-4">
        <input
          type="text"
          className="form-control"
          placeholder="Search by name, brand, or color..."
          value={searchTerm}
          onChange={handleSearch}
        />
      </section>

      {editingProduct && (
        <section className="edit-product card mb-4">
          <div className="card-header bg-warning text-white">
            <h3>Edit Product</h3>
          </div>
          <div className="card-body">
            <form>
            <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Product ID"
                  value={editProduct.productId}
                  onChange={(e) => setEditProduct({ ...editProduct, productId: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Product Name"
                  value={editProduct.productName}
                  onChange={(e) => setEditProduct({ ...editProduct, productName: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Brand"
                  value={editProduct.brand}
                  onChange={(e) => setEditProduct({ ...editProduct, brand: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="number"
                  className="form-control"
                  placeholder="Price"
                  value={editProduct.price}
                  onChange={(e) => setEditProduct({ ...editProduct, price: parseFloat(e.target.value) })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Category ID"
                  value={editProduct.categoryId}
                  onChange={(e) => setEditProduct({ ...editProduct, categoryId: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Color"
                  value={editProduct.color}
                  onChange={(e) => setEditProduct({ ...editProduct, color: e.target.value })}
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Image URL"
                  value={editProduct.imageURL}
                  onChange={(e) => setEditProduct({ ...editProduct, imageURL: e.target.value })}
                />
              </div>
              <button
                type="button"
                className="btn btn-info"
                onClick={handleEditProduct}
              >
                Update Product
              </button>
              <button
                type="button"
                className="btn btn-secondary ms-2"
                onClick={() => setEditingProduct(null)}
              >
                Cancel
              </button>
            </form>
          </div>
        </section>
      )}

      <section className="product-list card">
        <div className="card-header bg-success text-white">
          <h3>Product List</h3>
        </div>
        <div className="card-body table-responsive">
          <table className="table table-striped table-bordered">
            <thead>
              <tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Brand</th>
                <th>Price</th>
                <th>Category ID</th>
                <th>Color</th>
                <th>Image</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredProducts.length ? (
                filteredProducts.map(product => (
                  <tr key={product.productId}>
                    <td>{product.productId}</td>
                    <td>{product.productName}</td>
                    <td>{product.brand}</td>
                    <td>Rs{product.price.toFixed(2)}</td>
                    <td>{product.categoryId}</td>
                    <td>{product.color}</td>
                    <td>
                      <img
                        src={imageURL}
                        alt={product.productName}
                        className="img-fluid"
                      />
                    </td>
                    <td>
                      <button
                        className="btn btn-warning btn-sm me-2"
                        onClick={() => handleEditClick(product)}
                      >
                        Edit
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDeleteProduct(product.productId)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7" className="text-center">No products found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

export default GetProducts;
