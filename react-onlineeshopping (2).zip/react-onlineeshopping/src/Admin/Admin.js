import React, { useState, useEffect } from "react";
import { Link, Outlet } from "react-router-dom";
import "./Admin.css"; // Import the updated CSS file

const Admin = () => {
  const [uname, setUname] = useState("");

  useEffect(() => {
    const u = sessionStorage.getItem("uname"); // Retrieve the username from session storage
    setUname(u || ""); // Set uname, defaulting to an empty string if null
  }, []);

  return (
    <div className="d-flex flex-column min-vh-100 admin-container">
      <header className="admin-header shadow sticky-top">
        <div className="container-fluid">
          <div className="d-flex justify-content-between align-items-center">
            <h1 className="admin-title">Admin Dashboard</h1>
            <nav className="admin-navbar">
              <ul className="navbar-nav d-flex flex-row">
                <li className="nav-item">
                  <Link className="nav-link" to="/home">
                    Home
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="allusers">
                    Get All Users
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="category">
                    Category
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="getall">
                    View Products
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="add">
                    Add Products
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="allorders">
                    Get Orders
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="profile">
                    UpdateProfile
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/login">
                    Log Out
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow-1 admin-main">
        <Outlet />
      </main>

      <footer className="footer bg-dark text-white text-center py-4 mt-auto">
        <div className="container">
          <p className="mb-0">&copy; 2024 ShopEase. All rights reserved.</p>
          <nav className="mt-2">
            <Link to="/about" className="text-white text-decoration-none mx-3">
              About Us
            </Link>
            <Link to="/contact" className="text-white text-decoration-none mx-3">
              Contact
            </Link>
            <Link to="/help" className="text-white text-decoration-none mx-3">
              Help
            </Link>
            <Link to="/mailus" className="text-white text-decoration-none mx-3">
              Mail Us
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  );
};

export default Admin;
