using Moq;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Repository;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace ProductTest
{
    public class UnitTest1
    {
        private readonly Mock<IProductRepository> productService;

        public UnitTest1()
        {
            this.productService = new Mock<IProductRepository>();
        }

        [Fact]
        public void Test_GetAllProducts()
        {
            // Arrange
            var productList = GetProductsData();
            productService.Setup(x => x.GetAllProducts()).Returns(productList);

            // Act
            var result = productService.Object.GetAllProducts().Result.ToList();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(productList.Result.Count, result.Count);
        }

        [Fact]
        public void Test_GetProductById()
        {
            // Arrange
            var productId = "1";
            var product = new Product
            {
                ProductId = "1",
                ProductName = "Updated Jeans",
                Price = 2200,
                CategoryId = "C0001",
                Brand = "Blue",
                Color = "Black",
            };

            productService.Setup(x => x.GetProductById(productId)).ReturnsAsync(product);

            // Act
            var result = productService.Object.GetProductById(productId).Result;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(productId, result.ProductId);
        }

        [Fact]
        public void Test_UpdateProduct()
        {
            // Arrange
            var product = new Product
            {
                ProductId = "1",
                ProductName = "Updated Jeans",
                Price = 2200,
                CategoryId = "C0001",
                Brand = "Blue",
                Color = "Black",
            };

            productService.Setup(x => x.Update(product)).Returns(Task.CompletedTask);

            // Act
            var result = productService.Object.Update(product);

            // Assert
            Assert.NotNull(result);
            productService.Verify(x => x.Update(product), Times.Once());
        }

        [Fact]
        public void Test_DeleteProduct()
        {
            // Arrange
            var productId = "1";

            productService.Setup(x => x.Delete(productId)).Returns(Task.CompletedTask);

            // Act
            var result = productService.Object.Delete(productId);

            // Assert
            Assert.NotNull(result);
            productService.Verify(x => x.Delete(productId), Times.Once());
        }

        private Task<List<Product>> GetProductsData()
        {
            List<Product> products = new List<Product>
            {
                new Product
                {
                    ProductId = "1",
                    ProductName = "Loose Jeans",
                    Price = 2000,
                    CategoryId = "C0002",
                    Color = "Blue",
                    Brand = "Levi's",
                },
                new Product
                {
                    ProductId = "2",
                    ProductName = "Slim Fit Shirt",
                    Price = 1500,
                    CategoryId = "C0001",
                    Color = "White",
                    Brand = "Zara",
                }
            };

            return Task.FromResult(products);
        }
    }
}
