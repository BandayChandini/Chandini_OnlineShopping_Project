﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OnlineShoppingAPI.Entities
{
    public class OrderItem
    {
        [Key]
        public string OrderItemId { get; set; }
        [ForeignKey("Order")]
        public Guid OrderId { get; set; }
        
        
        [ForeignKey("Product")]
        public string ProductId { get; set; }
        public double Price { get; set; }
        public double TotalPrice {  get; set; }
        public int Quantity { get; set; }
        [JsonIgnore]

        public Order? Order { get; set; }
        [JsonIgnore]
        
        public Product? Product { get; set; }
    }
}
