﻿using OnlineShoppingAPI.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace OnlineShoppingAPI.Models
{
    public class CartDTO
    {
        public string CartItemId { get; set; }
        public string ProductId { get; set; }
        public string? CategoryName { get; set; }
        public string ProductName {  get; set; }
        public string Brand { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }
        public double TotalPrice { get; set; }
    }
}
