using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Repository;
using System.Text;

namespace OnlineShoppingAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Create a new WebApplication instance
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            // Registering the DbContext for interacting with the database
            builder.Services.AddDbContext<OnlineShoppingContext>();

            // Registering repositories as services for Dependency Injection (DI)
            builder.Services.AddTransient<IProductRepository, ProductRepository>();
            builder.Services.AddTransient<IOrderRepository, OrderRepository>();
            builder.Services.AddTransient<IUserRepository, UserRepository>();
            builder.Services.AddTransient<ICategoryRepository, CategoryRepository>();
            builder.Services.AddTransient<IFavoriteRepository, FavoriteRepository>();
            builder.Services.AddTransient<ITransactionRepository, TransactionRepository>();
            builder.Services.AddTransient<ICartItemRepository, CartItemRepository>();
            builder.Services.AddTransient<IOrderItemRepository, OrderItemRepository>();

            // Adding controller services to handle incoming HTTP requests
            // builder.Services.AddControllers();
            builder.Services.AddControllers(options =>
           options.Filters.Add(new GlobalExceptionFilter()));
            //configure the cors
            builder.Services.AddCors(c =>
            {
                c.AddPolicy("AllowOrigin", options => options.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
            });

            // Setting up JWT-based authentication
            builder.Services.AddAuthentication(options =>
            {
                // Specifying the default authentication scheme as JWT Bearer
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(o =>
            {
                // Configuring JWT token validation parameters
                o.TokenValidationParameters = new TokenValidationParameters
                {
                    // Validating the issuer (who issued the token)
                    ValidIssuer = builder.Configuration["Jwt:Issuer"],
                    // Validating the audience (who is supposed to consume the token)
                    ValidAudience = builder.Configuration["Jwt:Audience"],
                    // Validating the signing key used to generate the token
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"])),
                    // Ensuring the token has a valid issuer
                    ValidateIssuer = true,
                    // Ensuring the token has a valid audience
                    ValidateAudience = true,
                    // Disable lifetime validation (set to true to enforce token expiry checks)
                    ValidateLifetime = false,
                    // Validating the signing key used in the token
                    ValidateIssuerSigningKey = true
                };
            });

            // Configuring Swagger for API documentation
            builder.Services.AddSwaggerGen(c =>
            {
                // Creating a Swagger document with API information
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "JWTToken_Auth_API",
                    Version = "v1"
                });

                // Defining the security scheme for JWT Bearer tokens
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 1safsfsdfdfd\"",
                });

                // Applying the security scheme to the API
                c.AddSecurityRequirement(new OpenApiSecurityRequirement {
                    {
                        new OpenApiSecurityScheme {
                            Reference = new OpenApiReference {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        new string[] {}
                    }
                });
            });

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            // Build the application
            var app = builder.Build();

            // Configure the HTTP request pipeline.

            // If in development mode, enable Swagger UI for API testing and exploration
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
                app.UseDeveloperExceptionPage();
                //app.UseExceptionHandler("/error");
            }
            app.UseCors("AllowOrigin");
            // Enabling authentication middleware
            app.UseAuthentication();

            // Enabling authorization middleware
            app.UseAuthorization();

            // Mapping controllers to handle incoming requests
            app.MapControllers();

            // Run the application
            app.Run();
        }
    }
}
