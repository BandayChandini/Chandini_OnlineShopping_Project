﻿using Microsoft.EntityFrameworkCore;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Models;
using OnlineShoppingAPI.Repository;

namespace OnlineShoppingAPI.Repository
{
    // The OrderRepository class provides methods to interact with Order entities in the database.
    public class OrderRepository : IOrderRepository
    {
        private readonly OnlineShoppingContext _context;

        // Constructor to initialize the context through dependency injection.
        public OrderRepository(OnlineShoppingContext context)
        {
            _context = context;
        }


        public async Task<bool> UpdateOrderStatus(Guid orderId, string newStatus)
        {
            // Find the order by orderId in the database
            var order = await _context.Orders.FindAsync(orderId);

            // Check if the order exists
            if (order == null)
            {
                return false; // Order not found
            }

            // Update the order status
            order.OrderStatus = newStatus;

            // Mark the entity as modified
            _context.Orders.Update(order);

            // Save changes to the database
            await _context.SaveChangesAsync();

            return true; // Successfully updated
        }






        // Method to add a new Order to the database.
        public async Task Add(Order order)
        {
            try
            {
                // Add the Order entity to the context and save changes to the database.
                await _context.Orders.AddAsync(order);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }

        // Method to delete an Order by its ID.
        public async Task Delete(Guid orderid)
        {
            try
            {
                // Find the Order entity by its ID.
                var order = await _context.Orders.FindAsync(orderid);
                if (order != null)
                {
                    // Remove the Order entity and save changes to the database.
                    _context.Orders.Remove(order);
                    await _context.SaveChangesAsync();
                }
                else
                {
                    // Log a message if the Order is not found.
                    Console.WriteLine("Order not found.");
                }
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }

        // Method to retrieve all Orders from the database.
        public async Task<List<Order>> GetAllOrders()
        {
            try
            {
                // Return a list of all Order entities in the database.
                return await _context.Orders.ToListAsync();
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }
        public async Task<List<Adminorder>> GetAllOrdersAsync()
        {
            var orders = await (from order in _context.Orders
                                join OrderItem in _context.OrderItems on order.OrderId equals OrderItem.OrderId
                                join product in _context.Products on OrderItem.ProductId equals product.ProductId
                                join user in _context.Users on order.UserId equals user.UserId
                                select new Adminorder
                                {
                                    OrderId = order.OrderId,
                                    ProductName = product.ProductName,
                                    Quantity = OrderItem.Quantity,
                                    OrderDate = order.OrderDate,
                                    Totalprice = order.Totalprice,
                                    Address = user.Address,
                                    OrderStatus = order.OrderStatus,
                                    UserId = user.UserId
                                }).ToListAsync();

            return orders;
        }

        public async Task<List<OrderDTO>> GetOrdersByUserIdAsync(string userId)
        {
            var orders = await (from o in _context.Orders
                                join oi in _context.OrderItems on o.OrderId equals oi.OrderId
                                join p in _context.Products on oi.ProductId equals p.ProductId
                                join t in _context.Transactions on o.OrderId equals t.OrderId
                                join u in _context.Users on o.UserId equals u.UserId
                                where o.UserId == userId // Filter by UserId
                                select new OrderDTO
                                {
                                    UserId = u.UserId, // From User table
                                    OrderId = o.OrderId, // From Order table
                                    OrderItemId = oi.OrderItemId.ToString(), // From OrderItem table
                                    Address = u.Address, // From User table
                                    OrderDate = o.OrderDate, // From Order table
                                    OrderStatus = o.OrderStatus, // From Order table
                                    Totalprice = o.Totalprice, // From Order table
                                    DeliveryDate = o.DeliveryDate, // From Order table
                                    Quantity = oi.Quantity, // From OrderItem table
                                    ProductId = p.ProductId.ToString(), // From Product table
                                    ProductName = p.ProductName, // From Product table
                                    TransactionMethod = t.TransactionMethod, // From Transaction table
                                    TransactionStatus = t.TransactionStatus, // From Transaction table
                                    TransactionDate = t.TransactionDate // From Transaction table
                                }).ToListAsync();

            return orders;
        }


        // Method to retrieve a specific Order by its ID.
        public async Task<Order> GetOrderById(Guid orderId)
        {
            try
            {
                // Find and return the Order entity by its ID.
                var orders = await _context.Orders.FindAsync(orderId);
                return orders;
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }



    }
}
