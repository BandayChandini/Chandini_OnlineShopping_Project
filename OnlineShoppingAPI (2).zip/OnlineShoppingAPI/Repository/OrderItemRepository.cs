﻿using Microsoft.EntityFrameworkCore;
using OnlineShoppingAPI.Entities;

namespace OnlineShoppingAPI.Repository
{
    // The OrderItemRepository class provides methods to interact with OrderItems in the database.
    public class OrderItemRepository : IOrderItemRepository
    {
        private readonly OnlineShoppingContext _context;

        // Constructor to initialize the context through dependency injection.
        public OrderItemRepository(OnlineShoppingContext context)
        {
            _context = context;
        }

        // Method to retrieve all OrderItems from the database.
        public async Task<List<OrderItem>> GetAllOrderItems()
        {
            try
            {
                // Return a list of all OrderItem entities in the database.
                return await _context.OrderItems.ToListAsync();
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }

        // Method to retrieve a specific OrderItem by its ID.
        public async Task<OrderItem> GetOrderItemById(string id)
        {
            try
            {
                // Find and return the OrderItem entity by its ID.
                var items = await _context.OrderItems.FindAsync(id);
                return items;
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }

        // Method to add a new OrderItem to the database.
        public async Task AddOrderItem(OrderItem orderitem)
        {
            try
            {
                // Add the OrderItem entity to the context and save changes to the database.
                await _context.OrderItems.AddAsync(orderitem);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }
    }
}
