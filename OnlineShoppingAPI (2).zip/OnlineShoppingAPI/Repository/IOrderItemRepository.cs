﻿using OnlineShoppingAPI.Entities;

namespace OnlineShoppingAPI.Repository
{
    public interface IOrderItemRepository
    {
        Task<List<OrderItem>> GetAllOrderItems();
        Task<OrderItem> GetOrderItemById(string id);
        Task AddOrderItem(OrderItem orderitem);

    }
}
