﻿using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Models;
namespace OnlineShoppingAPI.Repository
{
    public interface IOrderRepository
    {
        Task Add(Order order);
        Task<Order> GetOrderById(Guid orderId);
        Task<List<OrderDTO>> GetOrdersByUserIdAsync(string userId);

        Task<List<Adminorder>> GetAllOrdersAsync();
        Task<List<Order>> GetAllOrders();
        Task Delete(Guid id);
        
    }
}
