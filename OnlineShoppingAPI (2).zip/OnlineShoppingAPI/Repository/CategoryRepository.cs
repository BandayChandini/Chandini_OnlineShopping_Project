﻿using Microsoft.EntityFrameworkCore;
using OnlineShoppingAPI.Entities;

namespace OnlineShoppingAPI.Repository
{
    // The CategoryRepository class provides methods to interact with the Categories in the database.
    public class CategoryRepository : ICategoryRepository
    {
        private readonly OnlineShoppingContext _context;
        private readonly IConfiguration _configuration;

        // Constructor to initialize the context and configuration through dependency injection.
        public CategoryRepository(OnlineShoppingContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        // Method to add a new Category to the database.
        public async Task AddCategory(Category category)
        {
            try
            {
                // Add the Category entity to the context and save changes to the database.
                await _context.Categories.AddAsync(category);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }
        public async Task<Category> GetCategoryByName(string categoryName)
        {
            try
            {
                var category = await _context.Categories.FirstOrDefaultAsync(x => x.CategoryName == categoryName);
                return category;
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
                Console.WriteLine("An error occurred while retrieving the product: " + ex.Message);
                throw;
            }
        }
        // Method to delete a Category from the database by its ID.
        public async Task DeleteCategory(string id)
        {
            try
            {
                // Find the Category entity by its ID.
                var category = await _context.Categories.FindAsync(id);
                if (category != null)
                {
                    // Remove the found Category from the context and save changes to the database.
                    _context.Categories.Remove(category);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }

        // Method to retrieve all Categories from the database.
        public async Task<List<Category>> GetAllCategories()
        {
            try
            {
                // Return a list of all Category entities in the database.
                return await _context.Categories.ToListAsync();
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }

        // Method to retrieve a specific Category by its ID.
        public async Task<Category> GetCategoryById(string id)
        {
            try
            {
                // Find and return the Category entity by its ID.
                var category = await _context.Categories.FindAsync(id);
                return category;
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }

        // Method to update an existing Category in the database.
        public async Task UpdateCategory(Category category)
        {
            try
            {
                // Update the Category entity in the context and save changes to the database.
                _context.Categories.Update(category);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }
    }
}
