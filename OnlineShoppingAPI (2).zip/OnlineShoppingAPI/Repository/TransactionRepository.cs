﻿using Microsoft.EntityFrameworkCore;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Models;

namespace OnlineShoppingAPI.Repository
{
    // The TransactionRepository class provides methods to interact with Transaction entities in the database.
    public class TransactionRepository : ITransactionRepository
    {
        private readonly OnlineShoppingContext _context;

        // Constructor to initialize the context through dependency injection.
        public TransactionRepository(OnlineShoppingContext context)
        {
            _context = context;
        }

       
        // Method to add a new Transaction to the database.
        public async Task AddTransaction(Transaction transaction)
        {
            try
            {
                // Add the Transaction entity to the context and save changes to the database.
                await _context.Transactions.AddAsync(transaction);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }

        // Method to retrieve a Transaction by its date.
        public async Task<Transaction> GetTransactionByDate(DateTime date)
        {
            try
            {
                // Find the first Transaction that matches the specified date.
                var transaction = await _context.Transactions
                    .FirstOrDefaultAsync(t => t.TransactionDate.Date == date.Date);

                return transaction;
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }

        // Method to retrieve a list of Transactions for a specific user ID.
        public async Task<List<Transaction>> GetTransactionById(string id)
        {
            try
            {
                // Retrieve all Transactions for the specified user ID.
                var transactions = await _context.Transactions
                    .Where(t => t.UserId == id)
                    .ToListAsync();

                return transactions;
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }
    }
}
