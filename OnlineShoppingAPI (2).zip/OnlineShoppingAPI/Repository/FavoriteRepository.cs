﻿using Microsoft.EntityFrameworkCore;
using OnlineShoppingAPI.Entities;

namespace OnlineShoppingAPI.Repository
{
    // The FavoriteRepository class provides methods to interact with the Favorites in the database.
    public class FavoriteRepository : IFavoriteRepository
    {
        private readonly OnlineShoppingContext _context;

        // Constructor to initialize the context through dependency injection.
        public FavoriteRepository(OnlineShoppingContext context)
        {
            _context = context;
        }

        // Method to add a new Favorite to the database.
        public async Task Add(Favorite favorite)
        {
            try
            {
                // Add the Favorite entity to the context and save changes to the database.
                await _context.Favorites.AddAsync(favorite);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }

        // Method to delete a Favorite from the database by its ID.
        public async Task Delete(string id)
        {
            try
            {
                // Find the Favorite entity by its ID.
                var favorite = await _context.Favorites.FindAsync(id);
                if (favorite != null)
                {
                    // Remove the found Favorite from the context and save changes to the database.
                    _context.Favorites.Remove(favorite);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }

        // Method to retrieve all Favorites from the database.
        public async Task<List<Favorite>> GetAllFavorites()
        {
            try
            {
                // Return a list of all Favorite entities in the database.
                return await _context.Favorites.ToListAsync();
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }

        // Method to retrieve a specific Favorite by its ID.
        public async Task<Favorite> GetFavoriteById(string favoriteId)
        {
            try
            {
                // Find and return the Favorite entity by its ID.
                var favorite = await _context.Favorites.FindAsync(favoriteId);
                return favorite;
            }
            catch (Exception ex)
            {
                // Throw an exception if something goes wrong.
                throw new Exception(ex.Message);
            }
        }

        // Method to update an existing Favorite in the database.
        public async Task Update(Favorite favorite)
        {
            try
            {
                // Update the Favorite entity in the context and save changes to the database.
                _context.Favorites.Update(favorite);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception to the console.
                Console.WriteLine(ex.Message);
            }
        }
    }
}


