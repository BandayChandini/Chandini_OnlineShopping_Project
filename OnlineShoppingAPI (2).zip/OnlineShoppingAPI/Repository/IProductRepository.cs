﻿using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Models;

namespace OnlineShoppingAPI.Repository
{
    public interface IProductRepository
    {
        Task Add(Product product);
        Task<Product> GetProductById(string productId);
        Task<List<Product>> GetAllProducts();
        Task<Product> GetProductByName(string ProductName);
        Task<IEnumerable<ProductDTO>> GetAllProductsAsync();
        Task AddProductAsync(AddProduct addProduct);


        Task<IEnumerable<Product>> GetItemsByFilterAsync(
  double? minPrice,
  double? maxPrice,
  string? categoryName,
  string? color,
  string? productname,
  string? brand);
        Task Delete(string id);
        Task Update(Product product);
        

    }
}
