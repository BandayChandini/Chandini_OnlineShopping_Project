﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Models;
using OnlineShoppingAPI.Repository;

namespace OnlineShoppingAPI.Controllers
{
    // The TransactionController handles operations related to transactions in the online shopping system.
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionRepository _transactionRepository;
        private IConfiguration _configuration;

        // Constructor for dependency injection of the Transaction repository
        public TransactionController(ITransactionRepository transactionRepository)
        {
            _transactionRepository = transactionRepository; // Inject the transaction repository
        }

        // Endpoint to get transactions by date, accessible by Admin and Customer roles
        [HttpGet, Route("GetTransactionByDate/{date}")]
        [Authorize(Roles = "Admin,Customer")]
        public async Task<IActionResult> Get([FromRoute] DateTime date)
        {
            try
            {
                // Retrieve transactions by date from the repository
                var transaction = await _transactionRepository.GetTransactionByDate(date);
                if (transaction != null)
                {
                    return StatusCode(200, transaction); // Return the transactions with status 200
                }
                else
                {
                    return StatusCode(404, "No transactions found for the given date"); // Return 404 if no transactions are found
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to get a specific transaction by ID, accessible by Admin and Customer roles
        [HttpGet, Route("GetTransactionById/{id}")]
        [Authorize(Roles = "Admin,Customer")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            try
            {
                // Retrieve the transaction by ID from the repository
                var transaction = await _transactionRepository.GetTransactionById(id);
                if (transaction != null)
                {
                    return StatusCode(200, transaction); // Return the transaction with status 200
                }
                else
                {
                    return StatusCode(404, "Invalid Id"); // Return 404 if the transaction is not found
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

       
        // Endpoint to add a new transaction, accessible by Admin and Customer roles
        [HttpPost, Route("AddTransaction")]
        [Authorize(Roles = "Admin,Customer")]
        public async Task<IActionResult> Add([FromBody] Transaction transaction)
        {
            try
            {
                // Check if the incoming model is valid
                if (ModelState.IsValid)
                {
                    // Generate a new unique ID for the transaction
                    transaction.TransactionId = Guid.NewGuid();

                    // Add the transaction to the repository
                    await _transactionRepository.AddTransaction(transaction);
                    return StatusCode(200, transaction); // Return the added transaction with status 200
                }
                else
                {
                    return BadRequest("Enter Valid Details!"); // Return bad request if the model is invalid
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }
    }
}
