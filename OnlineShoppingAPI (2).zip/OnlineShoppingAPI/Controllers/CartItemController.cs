﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Repository;

namespace OnlineShoppingAPI.Controllers
{
    // This controller manages CRUD operations for Cart Items
    [Route("api/[controller]")]
    [ApiController]
    //[AllowAnonymous] // Allows anonymous access by default, but specific actions are protected by role-based authorization
    public class CartItemController : ControllerBase
    {
        private readonly ICartItemRepository _cartitemRepository;
        private IConfiguration _configuration;

        // Constructor for dependency injection
        public CartItemController(ICartItemRepository cartitemRepository)
        {
            _cartitemRepository = cartitemRepository; // Inject the cart item repository
        }
        [Authorize(Roles = "Customer")]
        [HttpDelete("DeleteCartByUserId/{userId}")]
        public async Task<IActionResult> DeleteCartByUserId(string userId)
        {
            var result = await _cartitemRepository.DeleteCartByUserId(userId);
            if (result)
            {
                return Ok(new { message = "Cart cleared successfully." });
            }
            else
            {
                return NotFound(new { message = "No cart items found for the user." });
            }
        }

        // Endpoint to get all cart items, accessible to Admin and Customer roles
        [HttpGet, Route("GetAllCartItems")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                // Retrieve all cart items from the repository
                var cartitem = await _cartitemRepository.GetAllCartItems();
                return StatusCode(200, cartitem); // Return the cart items with status 200
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to get a specific cart item by ID, accessible to Admin and Customer roles
        [HttpGet, Route("GetCartItem/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            try
            {
                // Retrieve the cart item by ID from the repository
                var cartitem = await _cartitemRepository.GetCartItemById(id);
                if (cartitem != null)
                {
                    return StatusCode(200, cartitem); // Return the cart item with status 200
                }
                else
                {
                    return StatusCode(404, "Invalid Id"); // Return 404 if the cart item is not found
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }

        }
        [HttpGet, Route("GetCartItemsByUserIdDTO/{userId}")]
        [Authorize(Roles = "Customer")]

        public async Task<IActionResult> GetCartItemsByUserIdDTO([FromRoute] string userId)
        {
            try
            {
                var cartItems = await _cartitemRepository.GetCartItemsByUserIdDTO(userId);
                return Ok(cartItems);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        // Endpoint to add a new cart item, accessible only to Customers
        [HttpPost, Route("AddCartItem")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Add([FromBody] CartItem cartitem)
        {
            try
            {
                // Check if the incoming model is valid
                if (ModelState.IsValid)
                {

                    cartitem.CartItemId = "C" + new Random().Next(1000, 9999);
                    // Add the cart item to the repository
                    await _cartitemRepository.AddCartItem(cartitem);
                    return StatusCode(200, cartitem); // Return the added cart item with status 200
                }
                else
                {
                    return BadRequest("Enter Valid Details!"); // Return bad request if the model is invalid
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to edit an existing cart item, accessible only to Customers
        [HttpPut, Route("EditCartItem")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Edit([FromBody] CartItem cartitem)
        {
            try
            {
                // Update the cart item in the repository
                await _cartitemRepository.UpdateCartItem(cartitem);
                return StatusCode(200, cartitem); // Return the updated cart item with status 200
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to delete a cart item by ID, accessible only to Customers
        [HttpDelete, Route("DeleteCartItem")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            try
            {
                // Delete the cart item by ID from the repository
                await _cartitemRepository.DeleteCartItem(id);
                return Ok(); // Return OK status if the deletion is successful
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }
        [HttpGet, Route("GetCartItemsByUserId/{userId}")]
                [Authorize(Roles = "Customer")]

        public async Task<IActionResult> GetCartItemsByUserId([FromRoute] string userId)
        {
            try
            {
                var cartItems = await _cartitemRepository.GetCartItemsByUserId(userId); // Retrieve all cart items for the specified user
                return Ok(cartItems); // Return 200 OK with the cart items
            }
            catch (Exception ex)
            {
                // Handle exceptions that may occur during the retrieval operation
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
