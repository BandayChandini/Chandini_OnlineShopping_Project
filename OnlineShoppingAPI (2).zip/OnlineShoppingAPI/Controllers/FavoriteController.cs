﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingAPI.Entities;
using OnlineShoppingAPI.Repository;

namespace OnlineShoppingAPI.Controllers
{
    // This controller handles CRUD operations for Favorite items
    [Route("api/[controller]")]
    [ApiController]
    public class FavoriteController : ControllerBase
    {
        private readonly IFavoriteRepository _favoriteRepository;
        private IConfiguration _configuration;

        // Constructor for dependency injection
        public FavoriteController(IFavoriteRepository favoriteRepository)
        {
            _favoriteRepository = favoriteRepository; // Inject the favorite repository
        }

        // Endpoint to get all favorite items, accessible to Admin and Customer roles
       // [Authorize(Roles = "Admin,Customer")]
       [HttpGet, Route("GetFavorites")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                // Retrieve all favorite items from the repository
                var favorites = await _favoriteRepository.GetAllFavorites();
                return StatusCode(200, favorites); // Return the favorite items with status 200
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to get a specific favorite item by ID, accessible to Admin and Customer roles
        //[Authorize(Roles = "Admin,Customer")]
        [HttpGet, Route("GetFavorites/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            try
            {
                // Retrieve the favorite item by ID from the repository
                var favorite = await _favoriteRepository.GetFavoriteById(id);
                if (favorite != null)
                {
                    return StatusCode(200, favorite); // Return the favorite item with status 200
                }
                else
                {
                    return StatusCode(404, "Invalid Id"); // Return 404 if the favorite item is not found
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to add a new favorite item, accessible only to Customers
       // [Authorize(Roles = "Customer")]
        [HttpPost, Route("AddFavorite")]
        public async Task<IActionResult> Add([FromBody] Favorite favorite)
        {
            try
            {
                // Check if the incoming model is valid
                if (ModelState.IsValid)
                {

                    // Add the favorite item to the repository
                    await _favoriteRepository.Add(favorite);
                    return StatusCode(200, favorite); // Return the added favorite item with status 200
                }
                else
                {
                    return BadRequest("Enter Valid Details!!"); // Return bad request if the model is invalid
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to edit an existing favorite item, accessible only to Customers
        //[Authorize(Roles = "Customer")]
        [HttpPut, Route("EditFavorite")]
        public async Task<IActionResult> Edit([FromBody] Favorite favorite)
        {
            try
            {
                // Update the favorite item in the repository
                await _favoriteRepository.Update(favorite);
                return StatusCode(200, favorite); // Return the updated favorite item with status 200
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }

        // Endpoint to delete a favorite item by ID, accessible only to Customers
        [HttpDelete, Route("DeleteFavorite")]
       // [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            try
            {
                // Delete the favorite item by ID from the repository
                await _favoriteRepository.Delete(id);
                return Ok(); // Return OK status if the deletion is successful
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); // Return bad request if an exception occurs
            }
        }
    }
}
